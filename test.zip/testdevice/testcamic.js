
var UUID_BASE_MIC = 0;
var UUID_BASE_CAM = 0;
var UUID_BASE = 0;
var globalUUID_CallbackFuncMap = {};
var globalUUID_OnSwfReadyFuncMapmic = {};
var globalUUID_OnSwfReadyFuncMapcam = {};
var globalUUID_OnSwfReadyFuncMapsound = {};
function Videosound(id, width, height, callbackFunction, params) {	
	if (typeof id == "number") {
		id = parseInt(id).toString();
	} else if (typeof id == "string"){
	}else{
		return;
	}
	if (typeof params == "object") {
		var len = 0;
		for (var i in params) {
			len++;
		}
		if (len) {
			this.params /*object*/ = params;
		}
	}
	this.id /*string*/ = id;
	this.uuid /*string*/ = generateUUID();
	this.width /*string*/ = width;
	this.height /*string*/ = height;
	this.params /*object*/ = null;
	this.handle = null;


	createVideosound(this.id, this.uuid, this.width, this.height, this.params);

     if (typeof callbackFunction == "function") 
	     globalUUID_CallbackFuncMap[this.uuid] = callbackFunction;
	 globalUUID_OnSwfReadyFuncMapsound[this.uuid] = this.onSwfReadysound;

}

Videosound.prototype.onSwfReadysound = function () {
	
	this.handle = document.getElementById(this.uuid);
	if (this.handle) {
	}else 
		alert("can't find swf");
	
}

Videosound.prototype.onstop = function(){

	if(this.handle)
		this.handle.onstop();
}

function Video(id, width, height, userid, callbackFunction, params) {	
	if (typeof id == "number") {
		id = parseInt(id).toString();
	} else if (typeof id == "string"){
	}else{
		return;
	}
	if (typeof params == "object") {
		var len = 0;
		for (var i in params) {
			len++;
		}
		if (len) {
			this.params /*object*/ = params;
		}
	}
	this.id /*string*/ = id;
	this.uuid /*string*/ = generateUUID();
	this.width /*string*/ = width;
	this.height /*string*/ = height;
	this.userid /*string*/ = userid;
	this.params /*object*/ = null;
	this.handle = null;


	createVideomic(this.id, this.uuid, this.width, this.height, userid, this.params);

	if (typeof callbackFunction == "function") 
		globalUUID_CallbackFuncMap[this.uuid] = callbackFunction;
	
	    globalUUID_OnSwfReadyFuncMapmic[this.uuid] = this.onSwfReadymic;

}

Video.prototype.onSwfReadymic = function () {
	
	this.handle = document.getElementById(this.uuid);

	if (this.handle) {

	}else 
		alert("can't find swf");
	
}

Video.prototype.getMicList = function ()/*array*/
{
	if (this.handle) {
		return this.handle.getMicList();
	}
}

// 上麦时，切换麦克风
Video.prototype.setMic = function (micID /*int*/) {
	if (this.handle) {
		if (typeof micID == "number" || typeof micID == "string") {
			micID = parseInt(micID);
		}else{
			return;
		}
		return this.handle.setMic(micID);
	}
}

//获取上行edgeIp
Video.prototype.getedgeip = function () {
	if (this.handle) {
		
		return this.handle.getedgeip();
	}
}
//获取下行edgeIp
Video.prototype.getplayedgeip = function () {
	if (this.handle) {
		
		return this.handle.getplayedgeip();
	}
}

//获取上麦带宽
Video.prototype.getbandwidth = function () {
	if(this.handle){
        return this.handle.getbandwidth();
	}
}
//获取播放带宽
Video.prototype.getdownloadw = function () {
	if(this.handle){
        return this.handle.getdownloadw();
	}
}

Video.prototype.addEventListener = function (callbackFunction) {
	if (typeof callbackFunc == "function") {
		globalUUID_CallbackFuncMap[this.uuid] = callbackFunction;
	}
}

function Videocam(id, width, height,callbackFunc, params) {	
	if (typeof id == "number") 
		id = parseInt(id).toString();
    else if (typeof id == "string"){}
	else
		return;
	
	if (typeof params == "object") {
		var len = 0;
		for (var i in params) {
			len++;
		}
		if (len) {
			this.params /*object*/ = params;
		}
	}
	this.id /*string*/ = id;
	this.uuid /*string*/ = generateUUID();
	this.width /*string*/ = width;
	this.height /*string*/ = height;
	this.params /*object*/ = null;
	this.handle = null;
	
	createVideocam(this.id, this.uuid, this.width, this.height, this.params);

	if (typeof callbackFunc == "function")
		globalUUID_CallbackFuncMap[this.uuid] = callbackFunc;
	
	    globalUUID_OnSwfReadyFuncMapcam[this.uuid] = this.onSwfReadycam;
	
}

Videocam.prototype.onSwfReadycam = function () {

	
	this.handle = document.getElementById(this.uuid);

	if (this.handle){
	}
	else 
		alert("can't find swf");
	
}


// 获取摄像头列表
Videocam.prototype.getCamList = function ()/*array*/
{
	if (this.handle) {
		return this.handle.getCamList();
	}
}

// 上麦时，切换摄像头
Videocam.prototype.setCam = function (camID /*int*/) {
	if (this.handle) {
		if (typeof camID == "number" || typeof camID == "string") {
			camID = parseInt(camID);
		}else{
			return;
		}
		return this.handle.setCam(camID);
	}
}

Videocam.prototype.addEventListener = function (callbackFunc) {
	if (typeof callbackFunc == "function") {
		globalUUID_CallbackFuncMap[this.uuid] = callbackFunc;
	}
}

// 回调消息
function lssCallBack(uuid, type, info) {
	if (globalUUID_CallbackFuncMap[uuid])
		globalUUID_CallbackFuncMap[uuid](type, info);
	
}
// 生成全局UUID
// 注意：不包含以下字符：. - + * \ /
function generateUUID() {
	UUID_BASE++;
	return ('vvMedia' + UUID_BASE);
}
// 创建SWF对象
function createVideomic(id, uuid, width, height, userid, param) {
	var displayid = id.toString();

    var SWF = "Checkmicrop.swf?"+new Date().getTime();
            var swfVersionStr = "10.2.0";
             
            var xiSwfUrlStr = "playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            flashvars.userid = userid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = uuid;//"Checkmicrop";
            attributes.name = uuid;//"Checkmicrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "218", "140", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
          
            swfobject.createCSS("#flashContent", "display:block;text-align:left;");	
}

// 创建SWF对象
function createVideocam(id, uuid, width, height, param) {
	var displayid = id.toString();

    var SWF = "Checkcamrop.swf?"+new Date().getTime();
    var swfVersionStr = "10.2.0";
         
            var xiSwfUrlStr = "playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = uuid;//"Checkcamrop";
            attributes.name = uuid;//"Checkcamrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "218", "140", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
         
            swfobject.createCSS("#flashContent", "display:block;text-align:left;");
}
//检测声音
function createVideosound(id, uuid, width, height, param) {
	var displayid = id.toString();

    var SWF = "Checksourop.swf?"+new Date().getTime();
    var swfVersionStr = "10.2.0";
         
            var xiSwfUrlStr = "playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = uuid;//"Checkcamrop";
            attributes.name = uuid;//"Checkcamrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "218", "140", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
         
            swfobject.createCSS("#flashContent", "display:block;text-align:left;");
}