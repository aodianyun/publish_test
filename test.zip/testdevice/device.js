var RTMP_MEDIA_READY = "RtmpMedia.Ready";
var RTMP_MEDIA_SOUND = "RtmpMedia.Sound";
var RTMP_MEDIA_NO_SOUND = "RtmpMedia.NoSound";
var _micIndexArray = [];
var _camIndexArray = [];
var _setID = null;
var _setdownID = null;
var _setipnum = null;
var _id = 1100;

var _boolmic = false;
var UUID_BASE_MIC = 0;
var UUID_BASE_CAM = 0;
var UUID_BASE = 0;
var globalUUID_CallbackFuncMap = {};
var globalUUID_OnSwfReadyFuncMapmic = {};
var globalUUID_OnSwfReadyFuncMapcam = {};
var globalUUID_OnSwfReadyFuncMapsound = {};

var globalUUID_OnSwfReadyFuncMapset = {};

$(function () {  
       var playermic = new Video( "player", 320, 240,_id,
        function(type, info){
            
            switch(type){
               case RTMP_MEDIA_READY:       
                    playermic.onSwfReadymic();
                    onSwfReady();
               break;
               case RTMP_MEDIA_SOUND:
               break;
               case RTMP_MEDIA_NO_SOUND:
               break;
               default:
               break;    
            }
        }, null);

     function onSwfReady(){

         _setipnum = setInterval(setipnum,1000);
    }

    function setipnum(){
    
       if(playermic.getedgeip() && playermic.getplayedgeip()){
     
         $("#upedge").css("color","#5b5").html(playermic.getedgeip());
         $("#playedge").css("color","#5b5").html(playermic.getplayedgeip());

              clearInterval(_setipnum);
              _setID = setInterval(GetIp,1000);
       }
    }

    function GetIp(){

      if(playermic.getbandwidth()){
          var num = playermic.getbandwidth();
          var amount = num.substring(0,4);
          
          $("#upbd").css("color","#5b5").html(num);
           if(amount > 10)
             $("#upbwid").css("color","#5b5").html("很好");
           else if(amount > 7 && amount < 10)
               $("#upbwid").css("color","#5b5").html("良好");
           else if(amount > 4 && amount < 7)
             $("#upbwid").css("color","#5b5").html("较好");
           else if(amount > 1 && amount < 4)
             $("#upbwid").css("color","#5b5").html("较差");
           else if(amount < 1)
             $("#upbwid").css("color","#5b5").html("差");

             clearInterval(_setID);
             _setdownID = setInterval(GetDown,1000);
        }
    }
   
    function GetDown(){

        if(playermic.getdownloadw()){
          var num = playermic.getdownloadw();
          var amount = num.substring(0,4);
         
          $("#playbw").css("color","#5b5").html(playermic.getdownloadw());
           if(amount > 10)
             $("#playbwid").css("color","#5b5").html("很好");
           else if(amount > 7 && amount < 10)
             $("#playbwid").css("color","#5b5").html("良好");
           else if(amount > 4 && amount < 7)
             $("#playbwid").css("color","#5b5").html("较好");
           else if(amount > 1 && amount < 4)
             $("#playbwid").css("color","#FA8072").html("较差");
           else if(amount < 1)
             $("#playbwid").css("color","#FA8072").html("差");
           clearInterval(_setdownID);

          //$("#sound_tests").removeClass("mfp-hide");
            testset();
        }
    }

    $("#sound_tests").on("click",".sound_result",function(){

       $(this).hasClass("btn_no")? ($("#idsound").css("color","#FA8072").html("未检测到声音"),$("#soundstate").css("color","#FA8072").html("请检查或更换耳机")) : 
                                   ($("#idsound").css("color","#5b5").html("正常"),$("#soundstate").html("--"));

       helper.closeModal();
       testmic();
    });


    $("#mic_test").on("click",".nextBtn",function(){
        
        if(_boolmic)
          $("#idmic").css("color","#5b5").html("正常"),$("#micstate").html("--");
        else
          $("#idmic").css("color","#FA8072").html("未检测到声音"),$("#micstate").css("color","#FA8072").html("请检查或更换麦克风")
        helper.closeModal();
        
        testcam();
    });


    $("#camera_test").on("click",".bootBtn",function(){

       $(this).hasClass("btn_no")? ($("#idcamera").css("color","#FA8072").html("未检测到视频"),$("#camerastate").css("color","#FA8072").html("请检查或更换摄像头")) : 
                                   ($("#idcamera").css("color","#5b5").html("正常"),$("#camerastate").html("--"));
        helper.closeModal();
        $(".checking_title").text("检测完毕！");
    });
});


function testmic(){
   
     helper.showModal($("#mic_test"));
     var playermic = new Video( "play_sound", 320, 240,_id,
        function(type, info){
            
            switch(type){
               case RTMP_MEDIA_READY:       
            
                    playermic.onSwfReadymic();
                    onSwfReady();
               break;
               case RTMP_MEDIA_SOUND:
                    _boolmic = true;
                    document.getElementById("visitip").style.display="";
               break;
               case RTMP_MEDIA_NO_SOUND:
                    document.getElementById("visitip").style.display="none";
               break;
               default:
               break;    
            }
        }, null);


      function onSwfReady(){
         
         var _micList = document.getElementById("mic_list");
         if (playermic){
            // micList
            for (var i=_micList.options.length-1; i>=0; i--){
                _micList.options.remove(i);
            }
            var micListArray = playermic.getMicList();
            for (var index in micListArray){
                var item = new Option(micListArray[index], micListArray[index]);
                _micList.options.add(item);
                _micIndexArray.push(index);
            }
        }

        $("#mic_list").on("change",function(){
           if (playermic){
              var micID = -1;
              for(var i=0; i<_micIndexArray.length; i++){
                  if(i == _micList.selectedIndex){
                     micID = _micIndexArray[i];
                     break;
                 }
              }
              document.getElementById("visitip").style.display="none";
              playermic.setMic(micID);
           }
        });
    }
}

//加载摄像头
function testcam(){

 helper.showModal($("#camera_test"));

  var playercam = new Videocam( "play_camera", 320, 240,
        function(type, info){
        
         switch(type){

            case RTMP_MEDIA_READY:
                 playercam.onSwfReadycam();
                 onSwfReadycam();
            break;
            default:
            break;    
         }
      }, null);
  var _camList = document.getElementById("camera_list");
    function onSwfReadycam(){

         if (playercam){
            // camList
            for (var i=_camList.options.length-1; i>=0; i--){
                _camList.options.remove(i);
            }

            var camListArray = playercam.getCamList();
            for (var index in camListArray){
                var item = new Option(camListArray[index], camListArray[index]);
                _camList.options.add(item);
                _camIndexArray.push(index);
            }
         }
   }
   $("#camera_list").on("change",function(){

       if (playercam){
            var camID = -1;
            for(var i=0; i<_camIndexArray.length; i++){

                if(i == _camList.selectedIndex){
                    camID = _camIndexArray[i];
                    break;
                }
            }

            playercam.setCam(camID);
        }
   });
}

function Videocam(id, width, height,callbackFunc, params) { 
    if (typeof id == "number") 
        id = parseInt(id).toString();
    else if (typeof id == "string"){}
    else
        return;
    
    if (typeof params == "object") {
        var len = 0;
        for (var i in params) {
            len++;
        }
        if (len) {
            this.params /*object*/ = params;
        }
    }
    this.id /*string*/ = id;
    this.uuid /*string*/ = generateUUID();
    this.width /*string*/ = width;
    this.height /*string*/ = height;
    this.params /*object*/ = null;
    this.handle = null;
    
    createVideocam(this.id, this.uuid, this.width, this.height, this.params);

    if (typeof callbackFunc == "function")
        globalUUID_CallbackFuncMap[this.uuid] = callbackFunc;
    
        globalUUID_OnSwfReadyFuncMapcam[this.uuid] = this.onSwfReadycam;
    
}

Videocam.prototype.onSwfReadycam = function () {

    
    this.handle = document.getElementById(this.uuid);

    if (this.handle){
    }
    else 
        alert("can't find swf");
    
}


// 获取摄像头列表
Videocam.prototype.getCamList = function ()/*array*/
{
    if (this.handle) {
        return this.handle.getCamList();
    }
}

// 上麦时，切换摄像头
Videocam.prototype.setCam = function (camID /*int*/) {
    if (this.handle) {
        if (typeof camID == "number" || typeof camID == "string") {
            camID = parseInt(camID);
        }else{
            return;
        }
        return this.handle.setCam(camID);
    }
}

Videocam.prototype.addEventListener = function (callbackFunc) {
    if (typeof callbackFunc == "function") {
        globalUUID_CallbackFuncMap[this.uuid] = callbackFunc;
    }
}


function testset(){
      helper.showModal($("#set_tests"));
      var playsetid = new Videoplayset("player_sound","320","240",
          function(type, info){
            
            switch(type){
               case RTMP_MEDIA_READY:       
                    playsetid.onSwfReadyset();
               break;
               default:
               break;    
            }
        }, null);

     $("#videoifame").css("width",214).css("height",137).attr("src" ,"http://192.168.1.18/player/demo/testdevice/check.html");
          setTimeout(function(){
                     document.getElementById("videoifame").contentWindow.showflashset();
                    },1000);

     $("#test2").on("click",function(){ 

         document.getElementById("videoifame").contentWindow.start();
        // if(playsetid.getmuted()){
            // document.getElementById('sss').style.visibility = "hidden";
            // playsetid.showflashseting();
            setTimeout(ontest3,1000);
        // return;
        // }
    });
}

function ontest3(){
  if(document.getElementById("videoifame").contentWindow.muted()){
     document.getElementById("videoifame").contentWindow.showflashset();
     return;
   }
    helper.closeModal();
    testsound();
  //document.getElementById('sss').style.visibility = "visible";
}

function Videoplayset(id, width, height, callbackFunction, params) {  
    if (typeof id == "number") {
        id = parseInt(id).toString();
    } else if (typeof id == "string"){
    }else{
        return;
    }
    if (typeof params == "object") {
        var len = 0;
        for (var i in params) {
            len++;
        }
        if (len) {
            this.params /*object*/ = params;
        }
    }
    this.id /*string*/ = id;
    this.uuid /*string*/ = generateUUID();
    this.width /*string*/ = width;
    this.height /*string*/ = height;
    this.params /*object*/ = null;
    this.handle = null;

    createVideoset("videoset", this.uuid ,"" ,"" ,null);
    
     if (typeof callbackFunction == "function") {
         globalUUID_CallbackFuncMap[this.uuid] = callbackFunction;
     }
     globalUUID_OnSwfReadyFuncMapset[this.uuid] = this.onSwfReadyset;

}


Videoplayset.prototype.onSwfReadyset = function () {
    
    this.handle = document.getElementById(this.uuid);
    if (this.handle) {
    }else 
        alert("can't find swf");
    
}

Videoplayset.prototype.getmuted = function(){

    if(this.handle)
        return this.handle.getmuted();
}

Videoplayset.prototype.showflashseting = function(){

    if(this.handle)
        return this.handle.showflashseting();
}



//测试声音
function testsound(){
 
      helper.showModal($("#sound_tests"));
      var playsound = new Videosound("player_sound","320","240",
          function(type, info){
            
            switch(type){
               case RTMP_MEDIA_READY:       
                    //playsound.onSwfReadysound();
               break;
               default:
               break;    
            }
        }, null);
}


function Videosound(id, width, height, callbackFunction, params) {  
    if (typeof id == "number") {
        id = parseInt(id).toString();
    } else if (typeof id == "string"){
    }else{
        return;
    }
    if (typeof params == "object") {
        var len = 0;
        for (var i in params) {
            len++;
        }
        if (len) {
            this.params /*object*/ = params;
        }
    }
    this.id /*string*/ = id;
    this.uuid /*string*/ = generateUUID();
    this.width /*string*/ = width;
    this.height /*string*/ = height;
    this.params /*object*/ = null;
    this.handle = null;

    createVideosound(this.id, this.uuid, this.width, this.height, this.params);
    
     if (typeof callbackFunction == "function") 
         globalUUID_CallbackFuncMap[this.uuid] = callbackFunction;
     globalUUID_OnSwfReadyFuncMapsound[this.uuid] = this.onSwfReadysound;

}


Video.prototype.getMicList = function ()/*array*/
{
    if (this.handle) {
        return this.handle.getMicList();
    }
}


Videosound.prototype.onSwfReadysound = function () {
    
    this.handle = document.getElementById(this.uuid);
    if (this.handle) {
    }else 
        alert("can't find swf");
    
}

Videosound.prototype.onstop = function(){

    if(this.handle)
        this.handle.onstop();
}

function Video(id, width, height, userid, callbackFunction, params) {   

    if (typeof id == "number") {
        id = parseInt(id).toString();
    } else if (typeof id == "string"){
    }else{
        return;
    }
    if (typeof params == "object") {
        var len = 0;
        for (var i in params) {
            len++;
        }
        if (len) {
            this.params /*object*/ = params;
        }
    }
    this.id /*string*/ = id;
    this.uuid /*string*/ = generateUUID();
    this.width /*string*/ = width;
    this.height /*string*/ = height;
    this.userid /*string*/ = userid;
    this.params /*object*/ = null;
    this.handle = null;

    if(id == 'player')
      createVideostate(this.id, this.uuid, this.width, this.height, userid, this.params);
    else
      createVideomic(this.id, this.uuid, this.width, this.height, userid, this.params);
    
      

    if (typeof callbackFunction == "function") 
        globalUUID_CallbackFuncMap[this.uuid] = callbackFunction;

        globalUUID_OnSwfReadyFuncMapmic[this.uuid] = this.onSwfReadymic;
}

Video.prototype.onSwfReadymic = function () {
    
    this.handle = document.getElementById(this.id);

    if (this.handle) {

    }else 
        alert("can't find swf");   
}
//获取上行edgeIp
Video.prototype.getedgeip = function () {
    if (this.handle) {
        
        return this.handle.getedgeip();
    }
}
//获取下行edgeIp
Video.prototype.getplayedgeip = function () {
    if (this.handle) {
        
        return this.handle.getplayedgeip();
    }
}
//获取上麦带宽
Video.prototype.getbandwidth = function () {
    if(this.handle){
        return this.handle.getbandwidth();
    }
}
//获取播放带宽
Video.prototype.getdownloadw = function () {
    if(this.handle){
        return this.handle.getdownloadw();
    }
}
// 上麦时，切换麦克风
Video.prototype.setMic = function (micID /*int*/) {
    if (this.handle) {
        if (typeof micID == "number" || typeof micID == "string") {
            micID = parseInt(micID);
        }else{
            return;
        }
        return this.handle.setMic(micID);
    }
}
Video.prototype.addEventListener = function (callbackFunction) {
    if (typeof callbackFunc == "function") {
        globalUUID_CallbackFuncMap[this.uuid] = callbackFunction;
    }
}
function generateUUID() {
    UUID_BASE++;
    return ('vvMedia' + UUID_BASE);
}
function lssCallBack(uuid, type, info) {
    if (globalUUID_CallbackFuncMap[uuid])
        globalUUID_CallbackFuncMap[uuid](type, info);
    
}

//检测网络情况
function createVideostate(id, uuid, width, height, userid, param) {
    var displayid = id.toString();
    var SWF = "./testdevice/CheckBwidth.swf?"+new Date().getTime();
            var swfVersionStr = "10.2.0";
             
            var xiSwfUrlStr = "./testdevice/playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            flashvars.userid = userid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = id;//"Checkmicrop";
            attributes.name = id;//"Checkmicrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "0", "0", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
          
            swfobject.createCSS("#flashContent", "display:block;text-align:left;"); 
}

function createVideomic(id, uuid, width, height, userid, param) {
    var displayid = id.toString();
    var SWF = "./testdevice/Checkmicrop.swf?"+new Date().getTime();
            var swfVersionStr = "10.2.0";
             
            var xiSwfUrlStr = "./testdevice/playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            flashvars.userid = userid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = id;//"Checkmicrop";
            attributes.name = id;//"Checkmicrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "218", "140", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
          
            swfobject.createCSS("#flashContent", "display:block;text-align:left;"); 
}
function changeSize(){
    $("#player").height(140).width(218);
}

//检测声音
function createVideosound(id, uuid, width, height, param) {
    var displayid = id.toString();

    var SWF = "./testdevice/Checksourop.swf?"+new Date().getTime();
    var swfVersionStr = "10.2.0";
         
            var xiSwfUrlStr = "./testdevice/playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = uuid;//"Checkcamrop";
            attributes.name = uuid;//"Checkcamrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "218", "140", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
         
            swfobject.createCSS("#flashContent", "display:block;text-align:left;");
}

// 检测摄像头
function createVideocam(id, uuid, width, height, param) {
    var displayid = id.toString();

    var SWF = "./testdevice/Checkcamrop.swf?"+new Date().getTime();
    var swfVersionStr = "10.2.0";
         
            var xiSwfUrlStr = "./testdevice/playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = uuid;//"Checkcamrop";
            attributes.name = uuid;//"Checkcamrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "218", "140", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
         
            swfobject.createCSS("#flashContent", "display:block;text-align:left;");
}


function createVideoset(id, uuid, width, height, param) {
    var displayid = id.toString();

    var SWF = "./testdevice/Checkflashset.swf?"+new Date().getTime();
    var swfVersionStr = "10.2.0";
         
            var xiSwfUrlStr = "./testdevice/playerProductInstall.swf";
            var flashvars = {};
            flashvars.uuid = uuid;
            var params = {};
            params.quality = "high";
            params.bgcolor = "#000000";
            params.allowscriptaccess = "always";
            params.allowfullscreen = "true";
            var attributes = {};
            attributes.id = uuid;//"Checkcamrop";
            attributes.name = uuid;//"Checkcamrop";
            attributes.align = "middle";
            swfobject.embedSWF(
                SWF, displayid, 
                "0", "0", 
                swfVersionStr, xiSwfUrlStr, 
                flashvars, params, attributes);
         
            swfobject.createCSS("#flashContent", "display:block;text-align:left;");
}